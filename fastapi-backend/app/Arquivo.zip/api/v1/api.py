from fastapi import APIRouter
from .endpoints import auth, users, projects, atividades, setores, documentos, casas_parceiras
from . import relatorios_diarios, credenciais_acesso, metricas_redes_sociais

api_router = APIRouter()

# Include all endpoint routers
api_router.include_router(auth.router, prefix="/auth", tags=["authentication"])
api_router.include_router(users.router, prefix="/users", tags=["users"])
api_router.include_router(projects.router, prefix="/projects", tags=["projects"])
api_router.include_router(atividades.router, prefix="/atividades", tags=["atividades"])
api_router.include_router(setores.router, prefix="/setores", tags=["setores"])
api_router.include_router(documentos.router, prefix="/documentos", tags=["documentos"])
api_router.include_router(casas_parceiras.router, prefix="/casas-parceiras", tags=["casas-parceiras"])
api_router.include_router(relatorios_diarios.router, prefix="/relatorios-diarios", tags=["relatorios-diarios"])
api_router.include_router(credenciais_acesso.router, prefix="/credenciais-acesso", tags=["credenciais-acesso"])
api_router.include_router(metricas_redes_sociais.router, prefix="/metricas-redes-sociais", tags=["metricas-redes-sociais"]) 