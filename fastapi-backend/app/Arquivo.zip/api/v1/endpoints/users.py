from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Dict, Any, Union
import uuid
from ....core.database import get_db
from ....schemas.user import UserCreate, UserResponse, UserUpdate, UserResponseFrontend
from ....services.user_service import UserService
from ....models.user import User
from ...deps import get_current_active_user, get_current_admin_user

router = APIRouter()


@router.get("/me", response_model=UserResponseFrontend)
def read_user_me(current_user: User = Depends(get_current_active_user)):
    """Get current user info"""
    return UserResponseFrontend.from_user(current_user)


@router.get("/for-assignment")
def get_users_for_assignment(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get users for assignment (no admin required)"""
    users = UserService.get_users(db, skip=0, limit=1000)
    return [
        {
            "id": str(user.id),
            "name": user.name,
            "email": user.email
        }
        for user in users
        if user.is_active
    ]


@router.get("/", response_model=List[UserResponseFrontend])
def read_users(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """Get all users (admin only)"""
    users = UserService.get_users(db, skip=skip, limit=limit)
    return [UserResponseFrontend.from_user(user) for user in users]


@router.get("/{user_id}", response_model=UserResponseFrontend)
def read_user(
    user_id: Union[str, uuid.UUID],
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """Get user by ID (admin only)"""
    user = UserService.get_user(db, user_id=user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    
    print(f"Debug - User found: id={user.id}, username={user.username}, email={user.email}")
    response = UserResponseFrontend.from_user(user)
    print(f"Debug - Response: name={response.name}")
    return response


@router.post("/", response_model=UserResponseFrontend)
def create_user(
    user_data: Dict[str, Any],
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """Create new user (admin only) - Compatible with frontend"""
    print(f"Debug - Received user_data: {user_data}")
    
    # Convert frontend data format to internal format
    if "name" in user_data:
        # Frontend format: name -> name + generate username
        name = user_data.get("name", "")
        # Generate username from name (lowercase, no spaces)
        username = name.lower().replace(" ", "_").replace(".", "_")
        
        user_create_data = {
            "name": name,
            "username": username,
            "email": user_data.get("email", ""),
            "password": user_data.get("password", ""),
            "is_active": True,
            "is_admin": user_data.get("role") == "admin"
        }
        
        # Handle setorId - convert to UUID if provided and not "none"
        setor_id = user_data.get("setorId")
        if setor_id and setor_id != "none":
            try:
                user_create_data["setor_id"] = uuid.UUID(setor_id)
            except ValueError:
                # Invalid UUID, ignore
                pass
        
        print(f"Debug - Converted user_create_data: {user_create_data}")
        user = UserCreate(**user_create_data)
    else:
        # Standard API format
        user = UserCreate(**user_data)
    
    # Check if user already exists
    db_user = UserService.get_user_by_email(db, email=user.email)
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    db_user = UserService.get_user_by_username(db, username=user.username)
    if db_user:
        raise HTTPException(status_code=400, detail="Username already registered")
    
    created_user = UserService.create_user(db=db, user=user)
    print(f"Debug - Created user: id={created_user.id}, name={created_user.name}, username={created_user.username}")
    
    response = UserResponseFrontend.from_user(created_user)
    print(f"Debug - Response: name={response.name}")
    return response


@router.put("/{user_id}", response_model=UserResponseFrontend)
def update_user(
    user_id: Union[str, uuid.UUID],
    user_data: Dict[str, Any],
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """Update user (admin only) - Compatible with frontend"""
    # Convert frontend data format to internal format
    if "name" in user_data:
        # Frontend format: name -> name, role -> is_admin, setorId -> setor_id
        update_data = {}
        if user_data.get("name"):
            update_data["name"] = user_data["name"]
            # Also update username based on name
            update_data["username"] = user_data["name"].lower().replace(" ", "_").replace(".", "_")
        if user_data.get("email"):
            update_data["email"] = user_data["email"]
        if user_data.get("password"):
            update_data["password"] = user_data["password"]
        if "role" in user_data:
            update_data["is_admin"] = user_data["role"] == "admin"
        
        # Handle setorId - convert to UUID if provided and not "none"
        if "setorId" in user_data:
            setor_id = user_data.get("setorId")
            if setor_id and setor_id != "none":
                try:
                    update_data["setor_id"] = uuid.UUID(setor_id)
                except ValueError:
                    # Invalid UUID, ignore
                    pass
            else:
                # None or "none" - clear setor
                update_data["setor_id"] = None
        
        user_update = UserUpdate(**update_data)
    else:
        # Standard API format
        user_update = UserUpdate(**user_data)
    
    db_user = UserService.update_user(db, user_id=user_id, user_update=user_update)
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return UserResponseFrontend.from_user(db_user)


@router.delete("/{user_id}")
def delete_user(
    user_id: Union[str, uuid.UUID],
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """Delete user (admin only)"""
    success = UserService.delete_user(db, user_id=user_id)
    if not success:
        raise HTTPException(status_code=404, detail="User not found")
    return {"message": "User deleted successfully"} 