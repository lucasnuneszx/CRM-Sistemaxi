from sqlalchemy.orm import Session
from typing import List, Optional, Union
import uuid
from ..models.project import Project
from ..schemas.project import ProjectCreate, ProjectUpdate


class ProjectService:
    """Project service for CRUD operations"""
    
    @staticmethod
    def get_project(db: Session, project_id: Union[str, uuid.UUID]) -> Optional[Project]:
        """Get project by ID"""
        return db.query(Project).filter(Project.id == project_id).first()
    
    @staticmethod
    def get_projects(db: Session, user_id: Optional[Union[str, uuid.UUID]] = None, skip: int = 0, limit: int = 100) -> List[Project]:
        """Get list of projects, optionally filtered by user"""
        query = db.query(Project)
        if user_id:
            query = query.filter(Project.owner_id == user_id)
        return query.offset(skip).limit(limit).all()
    
    @staticmethod
    def create_project(db: Session, project: ProjectCreate, owner_id: Union[str, uuid.UUID]) -> Project:
        """Create new project"""
        db_project = Project(
            name=project.name,
            description=project.description,
            status=project.status,
            startDate=project.startDate,
            endDate=project.endDate,
            budget=project.budget,
            owner_id=owner_id
        )
        db.add(db_project)
        db.commit()
        db.refresh(db_project)
        return db_project
    
    @staticmethod
    def update_project(db: Session, project_id: Union[str, uuid.UUID], project_update: ProjectUpdate) -> Optional[Project]:
        """Update project"""
        db_project = db.query(Project).filter(Project.id == project_id).first()
        if not db_project:
            return None
        
        update_data = project_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_project, field, value)
        
        db.commit()
        db.refresh(db_project)
        return db_project
    
    @staticmethod
    def delete_project(db: Session, project_id: Union[str, uuid.UUID]) -> bool:
        """Delete project"""
        db_project = db.query(Project).filter(Project.id == project_id).first()
        if not db_project:
            return False
        
        db.delete(db_project)
        db.commit()
        return True 