from pydantic_settings import BaseSettings
from typing import Optional, List
import os


class Settings(BaseSettings):
    """Application settings"""
    
    # Database
    database_url: str = "sqlite:///./squad.db"
    
    # JWT
    jwt_secret_key: str = "your-super-secret-jwt-key"
    jwt_algorithm: str = "HS256"
    jwt_access_token_expire_minutes: int = 1440
    
    # Environment
    environment: str = "development"
    
    # API
    api_v1_str: str = "/api/v1"
    project_name: str = "Squad API"
    project_version: str = "1.0.0"
    
    # CORS
    backend_cors_origins: List[str] = ["http://localhost:3000", "http://localhost:3001"]

    # MinIO Settings
    minio_endpoint: str = "s3api.sellhuub.com"
    minio_access_key: str = "3kmZMXrzfPmzwxTxuHwQ"
    minio_secret_key: str = "NFVv61Z0ZhKXbRhZSIPHo1wZa9FEcvFGZsUsPCsn"
    minio_bucket_name: str = "squad"
    minio_use_ssl: bool = True

    class Config:
        env_file = os.getenv("ENV_FILE", "config.env")
        case_sensitive = False
        # Map environment variables to class attributes
        fields = {
            "database_url": {"env": "DATABASE_URL"},
            "jwt_secret_key": {"env": "JWT_SECRET_KEY"},
            "jwt_algorithm": {"env": "JWT_ALGORITHM"},
            "jwt_access_token_expire_minutes": {"env": "JWT_ACCESS_TOKEN_EXPIRE_MINUTES"},
            "environment": {"env": "ENVIRONMENT"},
            "minio_endpoint": {"env": "MINIO_ENDPOINT"},
            "minio_access_key": {"env": "MINIO_ACCESS_KEY"},
            "minio_secret_key": {"env": "MINIO_SECRET_KEY"},
            "minio_bucket_name": {"env": "MINIO_BUCKET_NAME"},
            "minio_use_ssl": {"env": "MINIO_USE_SSL"},
        }


# Create global settings instance
settings = Settings() 