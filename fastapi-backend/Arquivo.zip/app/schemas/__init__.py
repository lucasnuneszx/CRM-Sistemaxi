from .auth import Token, TokenData, LoginRequest
from .user import UserResponse, UserCreate, UserUpdate, UserBase
from .project import ProjectResponse, ProjectCreate, ProjectUpdate, ProjectBase
from .atividade import (AtividadeResponse, AtividadeCreate, AtividadeUpdate, AtividadeBase, 
                        ProjetoNested, UserNested, SetorNested)
from .setor import SetorResponse, SetorCreate, SetorUpdate, SetorBase
from .documento import DocumentoBase, DocumentoCreate, DocumentoUpdate, DocumentoResponse, DownloadURL

__all__ = [
    "UserResponse", "UserCreate", "UserUpdate", "UserBase",
    "ProjectResponse", "ProjectCreate", "ProjectUpdate", "ProjectBase",
    "AtividadeResponse", "AtividadeCreate", "AtividadeUpdate", "AtividadeBase",
    "ProjetoNested", "UserNested", "SetorNested",
    "SetorResponse", "SetorCreate", "SetorUpdate", "SetorBase",
    "Token", "TokenData", "LoginRequest",
    "DocumentoBase", "DocumentoCreate", "DocumentoUpdate", "DocumentoResponse",
    "DownloadURL"
]

# Resolve forward references
ProjectResponse.model_rebuild()
AtividadeResponse.model_rebuild()
DocumentoResponse.model_rebuild()
ProjetoNested.model_rebuild()
UserNested.model_rebuild()
SetorNested.model_rebuild()
UserResponse.model_rebuild()
SetorResponse.model_rebuild()

# No need to print here anymore, was for initial debugging
# print("Schemas rebuilt") 