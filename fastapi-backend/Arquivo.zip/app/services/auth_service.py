from sqlalchemy.orm import Session
from typing import Optional
from ..models.user import User
from ..schemas.auth import LoginRequest
from ..core.security import verify_password, create_access_token


class AuthService:
    """Authentication service"""
    
    @staticmethod
    def authenticate_user(db: Session, username: str, password: str) -> Optional[User]:
        """Authenticate user by username/email and password"""
        # Try to find by username or email
        user = db.query(User).filter(
            (User.username == username) | (User.email == username)
        ).first()
        
        if not user:
            return None
            
        if not verify_password(password, user.hashed_password):
            return None
            
        return user
    
    @staticmethod
    def create_admin_fallback(db: Session) -> Optional[User]:
        """Create admin fallback authentication"""
        # Check if admin@admin.com user exists
        admin_user = db.query(User).filter(User.email == "admin@admin.com").first()
        if admin_user and verify_password("admin", admin_user.hashed_password):
            return admin_user
        return None
    
    @staticmethod
    def login(db: Session, login_data: LoginRequest) -> Optional[dict]:
        """Login user and return token"""
        # Try normal authentication
        user = AuthService.authenticate_user(db, login_data.username, login_data.password)
        
        # If normal auth fails, try admin fallback
        if not user:
            user = AuthService.create_admin_fallback(db)
        
        if not user:
            return None
        
        # Create access token
        access_token = create_access_token(data={"sub": str(user.id)})
        
        return {
            "access_token": access_token,
            "token_type": "bearer",
            "user": {
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "is_admin": user.is_admin
            }
        } 