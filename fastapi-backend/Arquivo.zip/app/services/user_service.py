from sqlalchemy.orm import Session, joinedload
from typing import List, Optional, Union
import uuid
from ..models.user import User
from ..schemas.user import UserCreate, UserUpdate
from ..core.security import get_password_hash


class UserService:
    """User service for CRUD operations"""
    
    @staticmethod
    def get_user(db: Session, user_id: Union[str, uuid.UUID]) -> Optional[User]:
        """Get user by ID with setor loaded"""
        return db.query(User).options(joinedload(User.setor)).filter(User.id == user_id).first()
    
    @staticmethod
    def get_user_by_email(db: Session, email: str) -> Optional[User]:
        """Get user by email"""
        return db.query(User).filter(User.email == email).first()
    
    @staticmethod
    def get_user_by_username(db: Session, username: str) -> Optional[User]:
        """Get user by username"""
        return db.query(User).filter(User.username == username).first()
    
    @staticmethod
    def get_users(db: Session, skip: int = 0, limit: int = 100) -> List[User]:
        """Get list of users with setor loaded"""
        return db.query(User).options(joinedload(User.setor)).offset(skip).limit(limit).all()
    
    @staticmethod
    def create_user(db: Session, user: UserCreate) -> User:
        """Create new user"""
        hashed_password = get_password_hash(user.password)
        db_user = User(
            name=user.name,
            username=user.username,
            email=user.email,
            hashed_password=hashed_password,
            is_active=user.is_active,
            is_admin=user.is_admin,
            setor_id=user.setor_id
        )
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
        # Load setor relationship
        db.refresh(db_user)
        return db.query(User).options(joinedload(User.setor)).filter(User.id == db_user.id).first()
    
    @staticmethod
    def update_user(db: Session, user_id: Union[str, uuid.UUID], user_update: UserUpdate) -> Optional[User]:
        """Update user"""
        db_user = db.query(User).filter(User.id == user_id).first()
        if not db_user:
            return None
        
        update_data = user_update.model_dump(exclude_unset=True)
        
        # Handle password update
        if "password" in update_data:
            update_data["hashed_password"] = get_password_hash(update_data.pop("password"))
        
        for field, value in update_data.items():
            setattr(db_user, field, value)
        
        db.commit()
        db.refresh(db_user)
        # Return with setor loaded
        return db.query(User).options(joinedload(User.setor)).filter(User.id == user_id).first()
    
    @staticmethod
    def delete_user(db: Session, user_id: Union[str, uuid.UUID]) -> bool:
        """Delete user"""
        db_user = db.query(User).filter(User.id == user_id).first()
        if not db_user:
            return False
        
        db.delete(db_user)
        db.commit()
        return True 