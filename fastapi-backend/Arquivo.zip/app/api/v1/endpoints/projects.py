from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
import uuid
from ....core.database import get_db
from ....schemas.project import ProjectCreate, ProjectResponse, ProjectUpdate
from ....services.project_service import ProjectService
from ....models.user import User
from ...deps import get_current_active_user

router = APIRouter()


@router.get("/", response_model=List[ProjectResponse])
@router.get("", response_model=List[ProjectResponse])  # Route without trailing slash
def read_projects(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get projects for current user"""
    projects = ProjectService.get_projects(
        db, user_id=current_user.id, skip=skip, limit=limit
    )
    return projects


@router.get("/{project_id}", response_model=ProjectResponse)
def read_project(
    project_id: uuid.UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get project by ID"""
    project = ProjectService.get_project(db, project_id=project_id)
    if project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Check if user owns the project or is admin
    if project.owner_id != current_user.id and not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    return project


@router.post("/", response_model=ProjectResponse)
@router.post("", response_model=ProjectResponse)  # Route without trailing slash
def create_project(
    project: ProjectCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Create new project"""
    return ProjectService.create_project(
        db=db, project=project, owner_id=current_user.id
    )


@router.put("/{project_id}", response_model=ProjectResponse)
def update_project(
    project_id: uuid.UUID,
    project_update: ProjectUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Update project"""
    # Check if project exists and user has permission
    project = ProjectService.get_project(db, project_id=project_id)
    if project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    
    if project.owner_id != current_user.id and not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    updated_project = ProjectService.update_project(
        db, project_id=project_id, project_update=project_update
    )
    return updated_project


@router.delete("/{project_id}")
def delete_project(
    project_id: uuid.UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Delete project"""
    # Check if project exists and user has permission
    project = ProjectService.get_project(db, project_id=project_id)
    if project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    
    if project.owner_id != current_user.id and not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    success = ProjectService.delete_project(db, project_id=project_id)
    if not success:
        raise HTTPException(status_code=404, detail="Project not found")
    
    return {"message": "Project deleted successfully"} 